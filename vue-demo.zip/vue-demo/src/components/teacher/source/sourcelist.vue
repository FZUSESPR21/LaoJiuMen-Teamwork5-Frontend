<template>
  <div>
    <div id="head">课程资源
      <p class="english">Source</p>
    </div>
    <div class="part">
    <p>我是关于老师内容，22222222</p>
    <p>我是关于内容，22222222</p>
    <p>我是关于内容，22222222</p>
    <p>我是关于内容，22222222</p>
    <p>我是关于内容，22222222</p>
    <p>我是关于内容，22222222</p>
    <p>我是关于内容，22222222</p>
    <p>我是关于内容，22222222</p>
    <p>我是关于内容，22222222</p>
    <p>我是关于内容，22222222</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "sourcelist"
}
</script>

<style scoped>
#head{
  background-color: white;
  font-size: 20px;
  height: 100px;
  margin-top: 8%;
}

.english{
  color: rgb(179, 179, 179);
  margin-top: 0;
  font-size: 15px;
}

.part{
  margin-top: -4%;
  background-color: rgb(228, 228, 228);
}
</style>
