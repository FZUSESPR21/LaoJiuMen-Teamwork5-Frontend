<template>
  <div>
    <div id="head">学生管理
      <p class="english">Manage</p>
    </div>
    <div class="part">
    <p>学生1，22222222</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "studentlist"
}
</script>

<style scoped>
#head{
  background-color: white;
  font-size: 20px;
  height: 100px;
  margin-top: 8%;
}

.english{
  color: rgb(179, 179, 179);
  margin-top: 0;
  font-size: 15px;
}

.part{
  margin-top: -4%;
  background-color: rgb(228, 228, 228);
}
</style>
