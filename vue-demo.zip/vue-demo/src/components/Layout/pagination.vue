<template>
    <el-pagination
  background
  layout="prev, pager, next"
  :total="1000">
</el-pagination>
</template>