<template>
  <div id="homephoto">
    <img src="../../assets/mainimg.png" id="homeimg">
  </div>
</template>

<script>

export default {
  name: "homeimg"
}
</script>

<style scoped>
#homephoto{
  width: 100%;
  height: 500px;
}

#homeimg{
width:100%;
  height: 100%;
}

</style>
