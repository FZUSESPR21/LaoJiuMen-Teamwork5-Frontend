<template>
  <div id="cloud">
    <img src="../../assets/back.png" id="cloudimg">
  </div>
</template>

<script>

export default {
  name: "cloudimg"
}
</script>

<style scoped>
#cloud{
  width: 100%;
  height: 300px;
}

#cloudimg{
width:100%;
  height: 100%;
}

</style>
