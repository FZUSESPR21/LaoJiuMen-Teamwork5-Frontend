<template>
  <div id="photo">

  </div>
</template>

<script>
export default {
  name: "photo"
}
</script>

<style scoped>
#photo{
  width: 100%;
  height: 280px;
  background-color: aquamarine;
}
</style>
