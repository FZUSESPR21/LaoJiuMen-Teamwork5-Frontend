<template>
  <div>
    <h3>我是登录</h3>
    <p>77777777</p>
  </div>
</template>

<script>
export default {
  name: "LoginBox"
}
</script>

<style scoped>

</style>
