<template>
  <div>
    <h3>我是设置新密码</h3>
    <p>我是新密码内容，66666666666</p>
  </div>
</template>

<script>
export default {
  name: "SetPassword"
}
</script>

<style scoped>

</style>
